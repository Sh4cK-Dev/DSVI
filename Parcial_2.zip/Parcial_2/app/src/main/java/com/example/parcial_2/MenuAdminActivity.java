package com.example.parcial_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuAdminActivity extends AppCompatActivity {
    Button CrearEvento, VerEventos, VerAsistencia, Logout;

    SharedPreferences credenciales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_admin);

        credenciales = getSharedPreferences("credenciales", MODE_PRIVATE);

        InicializarControles();

        CrearEvento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rederigirCrearEventoActivity();
            }
        });

        VerEventos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rederigirVerEventos();
            }
        });

        VerAsistencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rederigirVerAsistencia();
            }
        });

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Logout();
            }
        });

    }

    private void InicializarControles() {
        CrearEvento = findViewById(R.id.btnCrearEvento);
        VerEventos = findViewById(R.id.btnVerEventos);
        VerAsistencia = findViewById(R.id.btnVerAsistencia);
        Logout = findViewById(R.id.btnLogout);
    }

    private void rederigirCrearEventoActivity() {
        Intent intent = new Intent(this, CrearEventoActivity.class);
        startActivity(intent);
    }

    private void rederigirVerEventos() {
        Intent intent = new Intent(this, EventosActivity.class);
        startActivity(intent);
    }

    private void rederigirVerAsistencia() {
        Intent intent = new Intent(this, AsistenciaActivity.class);
        startActivity(intent);
    }

    private void Logout() {
        //Borrar Credenciales Almacenadas
        SharedPreferences.Editor editor = credenciales.edit();
        editor.clear();
        editor.commit();

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
