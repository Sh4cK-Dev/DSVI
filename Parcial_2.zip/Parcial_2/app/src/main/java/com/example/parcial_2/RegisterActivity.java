package com.example.parcial_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    EditText editName, editCedula, editUser, editPass;
    Button registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        InicializarControles();
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrar();
                limpiarEditText();
            }
        });
    }
    private void InicializarControles() {
        editName = findViewById(R.id.editName);
        editCedula = findViewById(R.id.editCedula);
        editUser = findViewById(R.id.editUser);
        editPass = findViewById(R.id.editPass);

       registerBtn = findViewById(R.id.registerBtn);
    }
    private void registrar() {
        String name = editName.getText().toString();
        String cedula = editCedula.getText().toString();
        String user = editUser.getText().toString();
        String pass = editPass.getText().toString();

        try{
                if(name.isEmpty() || cedula.isEmpty() || user.isEmpty() || pass.isEmpty()){
                    Toast.makeText(this, "Todos los campos son requeridos", Toast.LENGTH_SHORT).show();
             }else{
                guardarDatos(name, cedula, user, pass);
                Toast.makeText(this, "Registro Exitoso", Toast.LENGTH_SHORT).show();
                rederigirMainActivity();
             }
            } catch (Exception e){
            Toast.makeText(this, "Error al Registrar", Toast.LENGTH_SHORT).show();
        }
    }

    private void guardarDatos(String name, String cedula, String user, String pass) {
        SharedPreferences credenciales = getSharedPreferences("credenciales", MODE_PRIVATE);
        SharedPreferences.Editor editor = credenciales.edit();
        editor.putString("name", name);
        editor.putString("cedula", cedula);
        editor.putString("user", user);
        editor.putString("pass", pass);
        editor.commit();
    }

    private void rederigirMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void limpiarEditText() {
        editName.setText("");
        editCedula.setText("");
        editUser.setText("");
        editPass.setText("");
    }
}
