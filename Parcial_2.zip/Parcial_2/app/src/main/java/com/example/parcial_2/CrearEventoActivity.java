package com.example.parcial_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class CrearEventoActivity extends AppCompatActivity {
    EditText fecha, hora, lugar, entrada;
    Button btn_return;

    ImageButton btn_logout;

    SharedPreferences credenciales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_evento);

        this.InicializarControles();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setOverflowIcon(ContextCompat.getDrawable(this, R.drawable.menu));

        credenciales = getSharedPreferences("credenciales", MODE_PRIVATE);

        btn_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CrearEventoActivity.this, MenuAdminActivity.class);
                startActivity(intent);
            }
        });

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });
    }

    private void InicializarControles(){
        fecha = (EditText) findViewById(R.id.txtFecha);
        hora = (EditText) findViewById(R.id.txtHora);
        lugar = (EditText) findViewById(R.id.txtLugar);
        entrada = (EditText) findViewById(R.id.txtEntrada);
        btn_return = (Button) findViewById(R.id.btn_return);
        btn_logout = (ImageButton) findViewById(R.id.btn_logout);
    }


    //MÉTODO PARA GUARDAR INFORMACIÓN EN EL ARCHIVO
    public void GuardarInfo(View v){
        try {
            String guardar =
                    fecha.getText().toString() +"|"+
                            hora.getText().toString() +"|"+
                            lugar.getText().toString() +"|"+
                            entrada.getText().toString() +"~";

            int res = GuardarArchivoEvento(guardar);
            if(res == 1){
                this.Mensajes("DATOS GUARDADOS CORRECTAMENTE");
                limpiarCampos();

            }else{
                this.Mensajes("NO SE GUARDARON LOS DATOS");
                limpiarCampos();
            }
        }catch (Exception e){
            this.Mensajes("OCURRIO UN ERROR"+e.getMessage());
        }
    }


    //MÉTODO PARA CREAR Y ACTUALIZAR ARCHIVO
    public int GuardarArchivoEvento(String guardar){
        try {
            //Verifica que el archivo ya exista y si tiene datos o no
            //Si existe y no tiene datos, se lo asigna, pero si tiene datos, el dato nuevo lo guarda sin perder los que ya existen
            String antiguo = "";

            BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput("informacion.txt")));
            String nuevo = br.readLine();

            if(!nuevo.isEmpty()){
                antiguo = nuevo;
            }

            OutputStreamWriter osw = new OutputStreamWriter(openFileOutput("informacion.txt", Context.MODE_PRIVATE));
            osw.write( antiguo + guardar); //variable guardar es sólo para guardar 1 dato al crear el file --
            // antiguro + guardar es para guardar el dato nuevo con los que ya existen
            osw.close();

            return 1;

        }catch (Exception ex){
            Log.e("Ficheros","ERROR AL ESCRIBIR FICHEROS A MEMORIA INTERNA");
        }
        return 0;
    }

    //MÉTODO PARA LOS MENSAJES
    private void Mensajes(String mensajito){
        Toast.makeText(this,mensajito,Toast.LENGTH_LONG).show();
    }

    //MÉTODO PARA LIMPIAR EDITTEXT
    private void limpiarCampos(){
        fecha.setText("");
        hora.setText("");
        lugar.setText("");
        entrada.setText("");
    }

    //MÉTODOS PARA EL MENÚ
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.item1) {
            startActivity(new Intent(this, EventosActivity.class));
            return true;
        } else if (itemId == R.id.item2) {
            startActivity(new Intent(this, CrearEventoActivity.class));
            return true;
        } else if (itemId == R.id.item3) {
            startActivity(new Intent(this, AsistenciaActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void logout(){
        SharedPreferences.Editor editor = credenciales.edit();
        editor.clear();
        editor.apply();
        // Redirigir a la pantalla de inicio de sesión
        Intent intent = new Intent(CrearEventoActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Finalizar la actividad actual
    }

}



