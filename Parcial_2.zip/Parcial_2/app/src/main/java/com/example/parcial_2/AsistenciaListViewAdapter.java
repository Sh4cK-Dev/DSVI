package com.example.parcial_2;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import Models.Asistencia;

public class AsistenciaListViewAdapter extends ArrayAdapter<Asistencia> {
    Context context;
    String informacionFileName;

    public AsistenciaListViewAdapter(Context context, List<Asistencia> asistenciaList, String informacionFileName) {
        super(context, 0, asistenciaList);
        this.context = context;
        this.informacionFileName = informacionFileName;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (convertView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.asistencia_template, parent, false);
        }
        Asistencia asistencia = getItem(position);

        TextView fechaTextView = listItemView.findViewById(R.id.Fecha);
        TextView horaTextView = listItemView.findViewById(R.id.Hora);
        TextView lugarTextView = listItemView.findViewById(R.id.Lugar);
        TextView entradaTextView = listItemView.findViewById(R.id.Entrada);
        TextView nombreTextView = listItemView.findViewById(R.id.Nombre);
        TextView cedulaTextView = listItemView.findViewById(R.id.Cedula);

        fechaTextView.setText(asistencia.getFecha());
        horaTextView.setText(asistencia.getHora());
        lugarTextView.setText(asistencia.getLugar());
        entradaTextView.setText(asistencia.getEntrada());
        nombreTextView.setText(asistencia.getNombre());
        cedulaTextView.setText(asistencia.getCedula());

        return listItemView;
    }

}

