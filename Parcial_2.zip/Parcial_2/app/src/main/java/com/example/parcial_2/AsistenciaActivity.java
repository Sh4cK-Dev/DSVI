package com.example.parcial_2;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import Models.Asistencia;

public class AsistenciaActivity extends AppCompatActivity {

  TextView Fecha, Hora, Lugar, Entrada, Nombre, Cedula;
  Button mostrarAsistencia;
    private ListView asistenciaListView;
    private AsistenciaListViewAdapter listViewAdapter;
    private List<Asistencia> asistenciaList;


  @Override
    protected void onCreate(Bundle savedInstanceState){
      super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asistencia);
        this.InicializarControles();

        asistenciaListView = findViewById(R.id.lista);
        asistenciaList = FileToList();

        listViewAdapter = new AsistenciaListViewAdapter(this, asistenciaList, "asistencia.txt");
        asistenciaListView.setAdapter(listViewAdapter);

    mostrarAsistencia.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        MostrarAsistencia(v);
      }
    });
  }

  private void InicializarControles(){
    Fecha = findViewById(R.id.Fecha);
    Hora = findViewById(R.id.Hora);
    Lugar = findViewById(R.id.Lugar);
    Entrada = findViewById(R.id.txtEntrada);
    Nombre = findViewById(R.id.Nombre);
    Cedula = findViewById(R.id.Cedula);
    mostrarAsistencia = findViewById(R.id.mostrarAsistencia);
  }

  //METODO PARA MOSTRAR LOS DATOS QUE ESTAN GUARDADOS EN EL ARCHIVO
  public void MostrarAsistencia(View v){
    if(asistenciaList.isEmpty()) {
        Toast.makeText(this, "No hay asistencia registrada", Toast.LENGTH_SHORT).show();
    } else {
      // Obtener el evento seleccionado
      int position = asistenciaListView.getCheckedItemPosition();
      if(position != ListView.INVALID_POSITION){
        Asistencia asistencia = asistenciaList.get(position);
        Fecha.setText(asistencia.getFecha());
        Hora.setText(asistencia.getHora());
        Lugar.setText(asistencia.getLugar());
        Entrada.setText(asistencia.getEntrada());
        Nombre.setText(asistencia.getNombre());
        Cedula.setText(asistencia.getCedula());
      } else {
        Toast.makeText(this, "Ningun Asistencia", Toast.LENGTH_SHORT).show();
      }
    }
  }

    //METODO PARA TRANSFORMAR LOS EVENTOS GUARDADOS EN EL ARCHIVO A UNA LISTA
    private List<Asistencia> FileToList(){
        List<Asistencia> asistenciaList = new ArrayList<Asistencia>();
        try{
          BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput("asistencia.txt")));
          String info = br.readLine();

          String[] arregloAsistencia = info.split("~");

          //Por cada cadena de asistencia (strAsistencia) tengo un arreglo (arregloAsistencia)
          for (String strAsistencia : arregloAsistencia) {
            String[] asistencia = strAsistencia.split("\\|");

            Asistencia asistenciaObj = new Asistencia(
                asistencia[0],
                asistencia[1],
                asistencia[2],
                asistencia[3],
                asistencia[4],
                asistencia[5]
                );
            asistenciaList.add(asistenciaObj);

          }
        } catch (Exception e){
          this.Meensajes("Ocurrio un error");
        }
        return asistenciaList;
    }

    //METODO PARA LOS MENSAJES
    private void Meensajes(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
