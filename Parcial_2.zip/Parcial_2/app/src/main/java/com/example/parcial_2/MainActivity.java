package com.example.parcial_2;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Button;
import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity {
    EditText editUsername, editPassword;
    Button Loginbtn, Registerbtn;

    SharedPreferences credenciales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        credenciales = getSharedPreferences("credenciales", MODE_PRIVATE);

        InicializarControles();

        //Este boton permite acceder tanto al administador como al Cliente
        Loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
                limpiarEditText();
            }
        });

        //Este boton lleva a la actividad de registro
        Registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        //Verificar si el usario ya esta logueado
        boolean logged = credenciales.getBoolean("logged", false);
        String userType = credenciales.getString("userType", "");

        if(logged){
            if(userType.equals("admin")){
                Intent intent = new Intent(MainActivity.this, MenuAdminActivity.class);
                startActivity(intent);
                finish();
            }else{
                Intent intent = new Intent(MainActivity.this, EventosActivity.class);
                startActivity(intent);
                finish();
            }
        }

    }

    private void InicializarControles() {
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Loginbtn = findViewById(R.id.Loginbtn);
        Registerbtn = findViewById(R.id.Registerbtn);
    }

    private void login() {
        String username = editUsername.getText().toString();
        String password = editPassword.getText().toString();


        //Datos del administrador quemados
        try{
            if(username.equals("admin") && password.equals("123456789")){
                    //Inicio exitoso para el administrador
                    Toast.makeText(this, "Bienvenido Administrador", Toast.LENGTH_SHORT).show();
                    //Guardar el indicador de inicio de sesion para el administrador
                    SharedPreferences.Editor editor = credenciales.edit();
                    editor.putBoolean("logged", true);
                    editor.putString("userType", "admin");
                    editor.commit();
                    //Redirigir al administrador a MenuAdminActivity
                    Intent intent = new Intent(this, MenuAdminActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    String user = credenciales.getString("user", "");
                    String pass = credenciales.getString("pass", "");
                    if (username.equals(user) && password.equals(pass)) {
                        //Inicio exitoso para el usuario
                        Toast.makeText(this, "Bienvenido " + user, Toast.LENGTH_SHORT).show();
                        //Guardar el indicador de inicio de sesion para el usuario
                        SharedPreferences.Editor editor = credenciales.edit();
                        editor.putBoolean("logged", true);
                        editor.putString("userType", "user");
                        editor.commit();
                        //Redirigir al usuario a EventosActivity
                        Intent intent = new Intent(this, EventosActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(this, "Datos Incorrectos", Toast.LENGTH_SHORT).show();
                    }
                }
        }catch (Exception e){
            Toast.makeText(this, "Error al Iniciar Sesion", Toast.LENGTH_SHORT).show();
        }
    }

    private void limpiarEditText() {
        editUsername.setText("");
        editPassword.setText("");
    }

}
