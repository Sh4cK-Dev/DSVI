package com.example.parcial_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import Models.Eventos;

public class EventosActivity extends AppCompatActivity {
    TextView fecha, hora, lugar, entrada;
    Button mostrarEventos;

    ImageButton btn_logout;

    SharedPreferences credenciales;

    private ListView eventosListView;
    private EventosListViewAdapter listViewAdapter;
    private List<Eventos> eventosList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos);

        credenciales = getSharedPreferences("credenciales", MODE_PRIVATE);

        eventosListView = findViewById(R.id.eventosCreados);
        eventosList = FileToList();
        this.InicializarControles();

        listViewAdapter = new EventosListViewAdapter(this, eventosList, "informacion.txt");
        eventosListView.setAdapter(listViewAdapter);

        mostrarEventos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MostrarEventos(v);
            }
        });

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });
    }

    private void InicializarControles(){
        fecha = findViewById(R.id.lblFecha);
        hora = findViewById(R.id.lblHora);
        lugar = findViewById(R.id.lblLugar);
        entrada = findViewById(R.id.lblEntrada);
        mostrarEventos = findViewById(R.id.mostrarEventos);
        btn_logout = findViewById(R.id.btn_logout);
    }

    //MÉTODO PARA MOSTRAR LOS DATOS QUE ESTÁN GUARDADOS EN EL ARCHIVO
    public void MostrarEventos(View v){
        if (eventosList.isEmpty()) {
            Toast.makeText(this, "No hay eventos", Toast.LENGTH_SHORT).show();
        } else {
            // Obtener el evento seleccionado en el ListView
            int posicionSeleccionada = eventosListView.getCheckedItemPosition();
            if (posicionSeleccionada != ListView.INVALID_POSITION) {
                Eventos eventoSeleccionado = eventosList.get(posicionSeleccionada);

                // Mostrar los datos del evento en los TextView correspondientes
                fecha.setText(eventoSeleccionado.getFecha());
                hora.setText(eventoSeleccionado.getHora());
                lugar.setText(eventoSeleccionado.getLugar());
                entrada.setText(eventoSeleccionado.getEntrada());
            } else {
                Toast.makeText(this, "Ningún evento seleccionado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //MÉTODO PARA TRANSFORMAR LOS EVENTOS CREADOS EN UNA LISTA
    private List<Eventos> FileToList(){
        List<Eventos> listEventos = new ArrayList<Eventos>();

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput("informacion.txt")));
            String info = br.readLine();

            String[] arregloEventos = info.split("~");

            //Por cada cadena de evento (strEvento) tengo un arreglo (arregloEventos)
            for (String strEvento : arregloEventos) {
                String[] camposEventos = strEvento.split("\\|");

                Eventos objEventos = new Eventos(
                        camposEventos[0],
                        camposEventos[1],
                        camposEventos[2],
                        camposEventos[3]
                );

                listEventos.add(objEventos);

            }
        }catch (Exception e){
            this.Mensajes("OCURRIO UN ERROR");
        }

        return listEventos;
    }

    //MÉTODO PARA LOS MENSAJES
    private void Mensajes(String mensajito){
        Toast.makeText(this,mensajito,Toast.LENGTH_LONG).show();
    }

    //Método para cerrar sesión
    private void logout(){
        SharedPreferences.Editor editor = credenciales.edit();
        editor.clear();
        editor.apply();

        // Redirigir a la pantalla de inicio de sesión
        Intent intent = new Intent(EventosActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Finalizar la actividad actual
    }

}


