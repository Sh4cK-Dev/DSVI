package com.example.parcial_2;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import Models.Eventos;

public class EventosListViewAdapter extends ArrayAdapter<Eventos> {
    Context context;
    SharedPreferences sharedPreferences;

    String informacionFileName;

    public EventosListViewAdapter(Context context, List<Eventos> eventosList,String informacionFileName) {
        super(context, 0, eventosList);
        this.context = context;
        this.informacionFileName = informacionFileName;
        sharedPreferences = context.getSharedPreferences("credenciales", Context.MODE_PRIVATE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (convertView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.eventos_template, parent, false);
        }
        Eventos eventos = getItem(position);

        ImageView flyerImageView = listItemView.findViewById(R.id.flyer);
        TextView fechaTextView = listItemView.findViewById(R.id.lblFecha);
        TextView horaTextView = listItemView.findViewById(R.id.lblHora);
        TextView lugarTextView = listItemView.findViewById(R.id.lblLugar);
        TextView entradaTextView = listItemView.findViewById(R.id.lblEntrada);
        Button btnConfirmar = listItemView.findViewById(R.id.btnConfirmar);


        fechaTextView.setText(eventos.getFecha());
        horaTextView.setText(eventos.getHora());
        lugarTextView.setText(eventos.getLugar());
        entradaTextView.setText(eventos.getEntrada());
        flyerImageView.setImageResource(R.drawable.flyer12);

        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmarAsistencia(eventos);
            }
        });

        return listItemView;


    }
    private void confirmarAsistencia (Eventos eventos){
        String name = sharedPreferences.getString("name", "");
        String cedula = sharedPreferences.getString("cedula", "");

        if (!name.isEmpty() && !cedula.isEmpty()) {
            String eventoFecha = "";
            String eventoHora = "";
            String eventoLugar = "";
            String eventoEntrada = "";

            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(context.openFileInput(informacionFileName)));
                String info = br.readLine();

                String[] arregloEventos = info.split("~");

                // Buscar el evento correspondiente en el archivo de información
                for (String strEvento : arregloEventos) {
                    String[] camposEventos = strEvento.split("\\|");

                    if (eventos.getFecha().equals(camposEventos[0]) && eventos.getHora().equals(camposEventos[1])
                            && eventos.getLugar().equals(camposEventos[2]) && eventos.getEntrada().equals(camposEventos[3])) {
                        eventoFecha = camposEventos[0];
                        eventoHora = camposEventos[1];
                        eventoLugar = camposEventos[2];
                        eventoEntrada = camposEventos[3];
                        break;
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(context, "Error al leer el archivo de información.", Toast.LENGTH_SHORT).show();
                return;
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(context, "Error al leer el archivo de información.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!eventoFecha.isEmpty() && !eventoHora.isEmpty() && !eventoLugar.isEmpty() && !eventoEntrada.isEmpty()) {
                String data =
                        eventoFecha +"|"+
                                eventoHora +"|"+
                                eventoLugar + "|" +
                                eventoEntrada +"|"+
                                name +"|"+
                                cedula +"~";

                try {
                    FileOutputStream fos = context.openFileOutput("asistencia.txt", Context.MODE_APPEND);
                    fos.write(data.getBytes());
                    fos.close();
                    Toast.makeText(context, "Asistencia confirmada.", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(context, "Error al guardar la asistencia.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "No se encontró el evento en el archivo de información.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(context, "Por favor, inicia sesión para confirmar la asistencia.", Toast.LENGTH_SHORT).show();
        }

    }
}
