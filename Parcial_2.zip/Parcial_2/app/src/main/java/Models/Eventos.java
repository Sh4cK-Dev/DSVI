package Models;

public class Eventos {
    private String fecha;
    private String hora;
    private String lugar;
    private String entrada;

    public Eventos() {
    }

    public Eventos(String fecha, String hora, String lugar, String entrada) {
        this.fecha = fecha;
        this.hora = hora;
        this.lugar = lugar;
        this.entrada = entrada;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getEntrada() {
        return entrada;
    }

    public void setEntrada(String entrada) {
        this.entrada = entrada;
    }
}

