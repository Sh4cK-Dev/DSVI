package Models;

public class Asistencia {
   private String fecha;
    private String hora;
    private String lugar;
    private String entrada;
    private String nombre;
    private String cedula;

    public Asistencia(String fecha, String hora, String lugar, String entrada, String nombre, String cedula) {
        this.fecha = fecha;
        this.hora = hora;
        this.lugar = lugar;
        this.entrada = entrada;
        this.nombre = nombre;
        this.cedula = cedula;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getHora() {
        return hora;
    }
    public void setHora(String hora) {
        this.hora = hora;
    }
    public String getLugar() {
        return lugar;
    }
    public void setLugar(String lugar) {
        this.lugar = lugar;
    }
    public String getEntrada() {
        return entrada;
    }
    public void setEntrada(String entrada) {
        this.entrada = entrada;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getCedula() {
        return cedula;
    }
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
}


